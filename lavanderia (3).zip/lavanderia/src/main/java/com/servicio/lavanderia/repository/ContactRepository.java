package com.servicio.lavanderia.repository;

import com.servicio.lavanderia.entity.Contact;
import org.springframework.data.repository.CrudRepository;

public interface ContactRepository extends CrudRepository<Contact, Integer> {
}
