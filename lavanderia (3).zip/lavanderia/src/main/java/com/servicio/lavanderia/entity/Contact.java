package com.servicio.lavanderia.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Entity
@RequiredArgsConstructor
@NoArgsConstructor
public class Contact {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @NonNull
    private String nombre;

    @NonNull
    private String servicio;

    @NonNull
    private String estado;

    @NonNull
    private Double precio;

    @NonNull
    private LocalDate fechaRegistro;

    @NonNull
    private LocalDate fechaEntrega;
}
