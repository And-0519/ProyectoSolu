package com.servicio.lavanderia;

import com.servicio.lavanderia.entity.Contact;
import com.servicio.lavanderia.repository.ContactRepository;
import org.modelmapper.ModelMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class LavanderiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LavanderiaApplication.class, args); }

	@Bean
	CommandLineRunner runner(ContactRepository contactRepository){
		return args -> {
				List<Contact> contacts = Arrays.asList(
						new Contact("Carlos", "Lavado", "Entregado", 50.0, LocalDate.now(), LocalDate.now()),
						new Contact("Luisa", "Planchado", "Pendiente", 60.0, LocalDate.now(), LocalDate.now()),
						new Contact("Mario", "Tenido", "En Proceso", 80.0, LocalDate.now(), LocalDate.now()),
						new Contact("Julia", "Lavado", "Pendiente", 50.0, LocalDate.now(), LocalDate.now()),
						new Contact("Dayana", "Tenido", "Entregado", 80.0, LocalDate.now(), LocalDate.now())
				);
				contactRepository.saveAll(contacts);
		};
	}
	@Bean
	ModelMapper modelMapper(){
		return new ModelMapper();
	}
}
