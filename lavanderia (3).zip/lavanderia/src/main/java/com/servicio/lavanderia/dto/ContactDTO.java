package com.servicio.lavanderia.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactDTO {
    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    @Email(message = "El servicio es invalido")
    @NotBlank(message = "El servicio es obligatorio")
    private String servicio;
}
