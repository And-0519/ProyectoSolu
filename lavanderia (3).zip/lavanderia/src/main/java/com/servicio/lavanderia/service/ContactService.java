package com.servicio.lavanderia.service;

import com.servicio.lavanderia.dto.ContactDTO;
import com.servicio.lavanderia.entity.Contact;
import com.servicio.lavanderia.exception.ResourceNotFoundException;
import com.servicio.lavanderia.repository.ContactRepository;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@AllArgsConstructor
@Service
public class ContactService {

    private final ContactRepository contactRepository;
    private final ModelMapper mapper;

    public Iterable<Contact> findAll() {
        return contactRepository.findAll();
    }

    public Contact findById(Integer id){
        return contactRepository
                .findById(id)
                .orElseThrow(ResourceNotFoundException::new);
    }

    public Contact create(ContactDTO contactDTO){
        Contact contact = mapper.map(contactDTO,Contact.class);
        contact.setFechaEntrega(LocalDate.now());
        contact.setFechaRegistro(LocalDate.now());
        return contactRepository.save(contact);
    }

    public Contact update(Integer id,ContactDTO contactDTO){
        Contact contactFromDb = findById(id);

        mapper.map(contactDTO,contactFromDb);

        return contactRepository.save(contactFromDb);
    }

    public void delete(Integer id){
        Contact contactFromDb = findById(id);
        contactRepository.delete(contactFromDb);
    }
}
